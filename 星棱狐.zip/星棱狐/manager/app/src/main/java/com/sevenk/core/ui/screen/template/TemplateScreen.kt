package com.sevenk.core.ui.screen.template

import android.content.ClipData
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.ClipEntry
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.dropUnlessResumed
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import com.sevenk.core.R
import com.sevenk.core.ui.LocalUiMode
import com.sevenk.core.ui.UiMode
import com.sevenk.core.ui.navigation3.LocalNavigator
import com.sevenk.core.ui.navigation3.Route
import com.sevenk.core.ui.util.isNetworkAvailable
import com.sevenk.core.ui.viewmodel.TemplateViewModel
import top.yukonga.miuix.kmp.basic.SnackbarHostState as MiuixSnackbarHostState

@Composable
fun AppProfileTemplateScreen() {
    val uiMode = LocalUiMode.current
    val navigator = LocalNavigator.current
    val viewModel = viewModel<TemplateViewModel>()
    val screenState by viewModel.uiState.collectAsStateWithLifecycle()
    val clipboard = LocalClipboard.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val requestKey = "template_edit"
    val snackBarHost = remember { SnackbarHostState() }
    val miuixSnackbarHost = remember { MiuixSnackbarHostState() }

    LaunchedEffect(Unit) {
        if (screenState.templateList.isEmpty()) {
            viewModel.fetchTemplates()
        }
    }

    LaunchedEffect(Unit) {
        navigator.observeResult<Boolean>(requestKey).collect { success ->
            if (success) {
                if (uiMode == UiMode.Miuix) {
                    navigator.clearResult(requestKey)
                }
                viewModel.fetchTemplates()
            }
        }
    }

    val importEmptyText = stringResource(R.string.app_profile_template_import_empty)
    val importSuccessText = stringResource(R.string.app_profile_template_import_success)
    val exportEmptyText = stringResource(R.string.app_profile_template_export_empty)

    fun showMessage(message: String) {
        scope.launch {
            if (uiMode == UiMode.Material) {
                snackBarHost.showSnackbar(message)
            } else {
                miuixSnackbarHost.showSnackbar(message)
            }
        }
    }

    val uiState = screenState.copy(offline = !isNetworkAvailable(context))
    val actions = TemplateActions(
        onBack = dropUnlessResumed { navigator.pop() },
        onRefresh = { forceSync ->
            scope.launch {
                viewModel.fetchTemplates(forceSync)
            }
        },
        onImport = {
            scope.launch {
                clipboard.getClipEntry()?.clipData?.getItemAt(0)?.text?.toString()?.let { templateText ->
                    if (templateText.isEmpty()) {
                        showMessage(importEmptyText)
                        return@let
                    }
                    viewModel.importTemplates(
                        templateText,
                        onSuccess = {
                            showMessage(importSuccessText)
                            viewModel.fetchTemplates(false)
                        },
                        onFailure = { showMessage(it) },
                    )
                }
            }
        },
        onExport = {
            scope.launch {
                viewModel.exportTemplates(
                    onTemplateEmpty = {
                        showMessage(exportEmptyText)
                    },
                    callback = { templateText ->
                        clipboard.setClipEntry(
                            ClipEntry(ClipData.newPlainText("template", templateText))
                        )
                    },
                )
            }
        },
        onCreateTemplate = {
            when (uiMode) {
                UiMode.Miuix -> navigator.navigateForResult(
                    Route.TemplateEditor(TemplateViewModel.TemplateInfo(), false),
                    requestKey,
                )

                UiMode.Material -> navigator.push(
                    Route.TemplateEditor(TemplateViewModel.TemplateInfo(), false)
                )
            }
        },
        onOpenTemplate = { template ->
            when (uiMode) {
                UiMode.Miuix -> navigator.navigateForResult(
                    Route.TemplateEditor(template, !template.local),
                    requestKey,
                )

                UiMode.Material -> navigator.push(
                    Route.TemplateEditor(template, !template.local)
                )
            }
        },
    )

    when (uiMode) {
        UiMode.Miuix -> AppProfileTemplateScreenMiuix(
            state = uiState,
            actions = actions,
            snackBarHost = miuixSnackbarHost,
        )

        UiMode.Material -> AppProfileTemplateScreenMaterial(
            state = uiState,
            actions = actions,
            snackBarHost = snackBarHost,
        )
    }
}
