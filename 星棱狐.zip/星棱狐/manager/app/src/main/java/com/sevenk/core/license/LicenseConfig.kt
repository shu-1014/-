package com.sevenk.core.license

/**
 * 🐾 卡密验证配置 —— 改成你自己微验后台的真实值！
 *
 * 对应后台位置：
 *  - APP_ID / APP_KEY / RC4_KEY ：「应用配置[全局] → 安全配置」页
 *  - SUCCESS_CODE             ：「状态码配置」页里的登录成功码
 *  - HOST / API_PATH          ：模板默认 wy.llua.cn / api/
 *      如果你的接口是 http://way.bux.com/dl/<你的码>，
 *      请把 HOST 改成 "way.bux.com"，API_PATH 改成 "dl/<你的码>/"
 */
object LicenseConfig {
    const val APP_ID = "85111"
    const val APP_KEY = "NQ72bkNE2ciNzHs"
    const val RC4_KEY = "sZ4pXHB8cbZ7d4W"
    const val SUCCESS_CODE = 80225

    const val HOST = "wy.llua.cn"
    const val API_PATH = "api/"

    /** 网络超时（毫秒），连接与读取共用。 */
    const val TIMEOUT_MS = 10000

    /**
     * 本程序版本号，用于 `api/?id=ini` 检查更新时和后台配置对比。
     *
     * 默认取真实构建版本 [com.sevenk.core.BuildConfig.VERSION_NAME]（例如 v2.27），
     * 这样在微验后台把版本号填成 App 的真实版本即可，不会因为写死而永远提示或永远不提示。
     * 想固定成某个值，直接改成字符串常量即可，例如：`val APP_VERSION = "1.00"`。
     * （用 val 而非 const：BuildConfig 字段不是编译期常量。）
     */
    val APP_VERSION: String = com.sevenk.core.BuildConfig.VERSION_NAME

    /**
     * 后台要求强制更新时，是否**禁止**用户继续使用（模板 `Weiyan::Update` 里是直接
     * `exit(0)` 杀进程，这里等价为锁在验证界面）。
     *
     * 默认 false = 只弹强提示，仍可输卡密进入，**不会把人锁死**。
     * 建议保持 false：`APP_VERSION` 取的是真实构建版本（如 `v2.27`），一旦微验后台
     * 填的版本号和它对不上、后台又勾了强制更新，设成 true 会导致 App 完全无法使用。
     * 确认后台版本号与 App 版本一致后，再打开这个开关。
     */
    const val FORCE_UPDATE_BLOCKS = false

    /**
     * 卡密验证总开关。
     * true = 启动必须卡密验证通过才能用；false = 完全跳过验证（恢复原版，用于安全兜底）。
     */
    const val ENABLED = true
}
