package com.sevenk.core.license

import java.security.MessageDigest

/**
 * 与 C++ 模板一致的加解密工具：MD5 / RC4 / hex <-> bin。
 * 算法与 res/Weiyan.h + res/Util.h 原样对应，保证兼容微验服务器。
 */
object Crypto {

    /** MD5 十六进制小写字符串。 */
    fun md5(s: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(s.toByteArray())
        return digest.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    /** 字节数组 -> 小写十六进制字符串。 */
    fun binToHex(bin: ByteArray): String {
        val sb = StringBuilder(bin.size * 2)
        for (b in bin) sb.append("%02x".format(b.toInt() and 0xFF))
        return sb.toString()
    }

    /** 十六进制字符串 -> 字节数组（按两个字符一组；奇数长度忽略末位）。 */
    fun hexToBin(hex: String): ByteArray {
        val n = hex.length / 2
        val out = ByteArray(n)
        for (i in 0 until n) {
            out[i] = hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
        return out
    }

    /** RC4 加解密（对称，同一函数可加密也可解密）。 */
    fun rc4(text: ByteArray, key: ByteArray): ByteArray {
        val s = IntArray(256) { it }
        var j = 0
        for (i in 0..255) {
            j = (j + s[i] + (key[i % key.size].toInt() and 0xFF)) % 256
            val t = s[i]; s[i] = s[j]; s[j] = t
        }
        var a = 0
        var k = 0
        val out = ByteArray(text.size)
        for (n in text.indices) {
            a = (a + 1) % 256
            k = (k + s[a]) % 256
            val t = s[a]; s[a] = s[k]; s[k] = t
            val idx = (s[a] + s[k]) % 256
            out[n] = (text[n].toInt() xor s[idx]).toByte()
        }
        return out
    }
}
