package com.sevenk.core.license

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * 卡密验证界面：打开 App 且未激活时显示，验证通过后进入主界面。
 *
 * 界面对应模板 `main.cpp` 的输出顺序：更新提示 → 系统公告 → 输入卡密。
 */
@Composable
fun LicenseScreen(
    state: LicenseUiState,
    onActivate: (String) -> Unit,
    onOpenUpdate: () -> Unit = {},
) {
    var kami by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("星棱狐 · 卡密验证", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                if (state.forceUpdate) "有新版本且需强制更新，请更新后再使用"
                else "输入激活卡密后即可使用",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(20.dp))

            // 更新提示（模板 Update 的输出）
            state.updateText?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (state.forceUpdate) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!state.updateUrl.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenUpdate, modifier = Modifier.fillMaxWidth()) {
                        Text("去下载新版本")
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // 系统公告（模板 Notice 的输出）
            state.notice?.let {
                Text("系统公告", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                // 不在此处再套 verticalScroll：外层 Column 已可滚动，
                // 同向嵌套滚动会触发 Compose 运行时异常。
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(20.dp))
            }

            OutlinedTextField(
                value = kami,
                onValueChange = { kami = it },
                label = { Text("卡密") },
                singleLine = true,
                enabled = !state.forceUpdate,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))

            Button(
                onClick = { onActivate(kami) },
                enabled = !state.checking && !state.forceUpdate,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (state.checking) {
                    CircularProgressIndicator(Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("验证中")
                } else {
                    Text("激活")
                }
            }

            state.error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            state.expireText?.let {
                Spacer(Modifier.height(12.dp))
                Text(it)
            }
        }
    }
}
