package com.sevenk.core.license

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Random

/**
 * 微验网络验证客户端（Kotlin 版）。
 *
 * 完整对应 C++ 模板 `res/Weiyan.h` + `res/Util.h` 的四个接口：
 *  - 检查更新  `api/?id=ini`       ← 模板 `Weiyan::Update`
 *  - 系统公告  `api/?id=notice`    ← 模板 `Weiyan::Notice`
 *  - 卡密登录  `api/?id=kmlogon`   ← 模板 `Weiyan::Login`
 *  - 远程变量  `api/?id=getvalue`  ← 模板 `Weiyan::getValue`
 *
 * 统一协议（与模板逐字段一致，保证兼容微验服务器）：
 * ```
 *  请求 body : app=应用ID [& data=hex( RC4(明文参数, RC4KEY) )]
 *  响应 body : hex( RC4(JSON文本, RC4KEY) )
 *  登录签名  : sign = MD5("kami=卡密&markcode=机器码&t=时间戳&" + APPKEY)
 *  登录反校验: check == MD5(time + APPKEY + value)
 * ```
 *
 * 说明：C++ 模板里那套「自建 DNS(223.5.5.5) + 裸 socket HTTP」是为了在没有
 * libc++ / 没有系统 DNS 的环境（如 AIDE 纯 NDK 可执行文件）里跑通；Android App
 * 内直接用 [HttpURLConnection] 即可，系统 DNS 已足够，无需复刻那段代码。
 */
class WeiyanClient(
    private val machineCode: String,
    private var kami: String = "",
) {

    private val host = LicenseConfig.HOST
    private val path = LicenseConfig.API_PATH

    /* ============================== 返回结构 ============================== */

    /** 卡密登录结果。 */
    data class LoginResult(
        val ok: Boolean,
        val msg: String,
        val expireTime: Long = 0,   // 到期时间戳(秒)，时间卡时有效
        val remain: Long = 0,       // 剩余次数，次数卡时有效
        val isTimeCard: Boolean = true,
    )

    /** 检查更新结果。 */
    data class UpdateResult(
        val ok: Boolean,
        val hasNew: Boolean = false,
        val currentVersion: String = "",
        val latestVersion: String = "",
        val changeLog: String = "",
        val downloadUrl: String = "",
        val forceUpdate: Boolean = false,   // 后台标记强制更新 且 确实有新版本
        val msg: String = "",
    )

    /** 公告结果。 */
    data class NoticeResult(
        val ok: Boolean,
        val text: String = "",
        val msg: String = "",
    )

    /* ============================== 对外接口 ============================== */

    /** 当前持有的卡密（登录成功后自动记录，[getValue] 依赖它）。 */
    fun currentKami(): String = kami

    /**
     * 检查更新（模板 `Weiyan::Update`）。
     *
     * 模板里强制更新是直接 `exit(0)` 杀进程；App 内不适合这么做，改为返回
     * [UpdateResult.forceUpdate]，由 UI 层决定如何拦截。
     *
     * @param currentVersion 本程序当前版本号
     */
    fun checkUpdate(currentVersion: String): UpdateResult {
        val resp = post("${path}?id=ini", "app=${LicenseConfig.APP_ID}")
        val json = parse(resp) ?: return UpdateResult(false, msg = "检查更新失败：服务器无响应")
        if (json.optInt("code") != 200) {
            return UpdateResult(false, msg = "检查更新失败：${json.optString("msg", "未知错误")}")
        }
        val m = json.optJSONObject("msg")
            ?: return UpdateResult(false, msg = "检查更新失败：响应格式异常")

        val latest = m.optString("version")
        val hasNew = latest.isNotEmpty() && latest != currentVersion
        val must = m.optString("app_update_must") == "y"
        return UpdateResult(
            ok = true,
            hasNew = hasNew,
            currentVersion = currentVersion,
            latestVersion = latest,
            changeLog = m.optString("app_update_show"),
            downloadUrl = m.optString("app_update_url"),
            forceUpdate = must && hasNew,
        )
    }

    /** 获取系统公告（模板 `Weiyan::Notice`）。 */
    fun notice(): NoticeResult {
        val resp = post("${path}?id=notice", "app=${LicenseConfig.APP_ID}")
        val json = parse(resp) ?: return NoticeResult(false, msg = "公告获取失败：服务器无响应")
        if (json.optInt("code") != 200) {
            return NoticeResult(false, msg = json.optString("msg", "公告获取失败"))
        }
        val m = json.optJSONObject("msg") ?: return NoticeResult(false, msg = "公告格式异常")
        return NoticeResult(true, m.optString("app_gg"))
    }

    /**
     * 卡密登录（模板 `Weiyan::Login`）。
     * 成功后会记录卡密，供 [getValue] 使用。
     */
    fun login(input: String): LoginResult {
        val card = input.trim()
        if (card.isEmpty()) return LoginResult(false, "请输入卡密")

        val value = (100000L + Random().nextInt(900000)).toString()
        val resp = post(
            "${path}?id=kmlogon",
            "app=${LicenseConfig.APP_ID}&data=${encrypt(signedParams(card, value))}",
        )
        val json = parse(resp) ?: return LoginResult(false, "服务器无响应或数据解析失败")

        if (json.optInt("code") != LicenseConfig.SUCCESS_CODE) {
            return LoginResult(false, json.optString("msg", "登录失败"))
        }

        // 设备时间校验（模板：偏差超过 ±30 秒判定时间不准）
        val time = json.optLong("time")
        val now = System.currentTimeMillis() / 1000
        if (kotlin.math.abs(time - now) > 30) {
            return LoginResult(false, "设备时间不准，请校正后重试")
        }

        // 服务端反校验（模板：check == MD5(time + APPKEY + value)）
        val expect = Crypto.md5("$time${LicenseConfig.APP_KEY}$value")
        if (json.optString("check") != expect) {
            return LoginResult(false, "校验失败")
        }

        val msg = json.optJSONObject("msg")
        val ktype = msg?.optString("ktype", "code") ?: "code"
        kami = card
        return if (ktype == "code") {
            LoginResult(true, "ok", expireTime = msg?.optLong("vip") ?: 0L)
        } else {
            LoginResult(true, "ok", remain = msg?.optLong("num") ?: 0L, isTimeCard = false)
        }
    }

    /**
     * 读取远程变量（模板 `Weiyan::getValue`），需先登录成功。
     * 模板把变量名放在 `value=` 字段里，签名规则与登录完全相同。
     */
    fun getValue(key: String): String {
        if (kami.isEmpty()) return "请先登录"
        val resp = post(
            "${path}?id=getvalue",
            "app=${LicenseConfig.APP_ID}&data=${encrypt(signedParams(kami, key))}",
        )
        val json = parse(resp) ?: return ""
        if (json.optInt("code") != 200) return json.optString("msg", "")
        return json.optJSONObject("msg")?.optString("msg") ?: ""
    }

    /* ============================== 内部实现 ============================== */

    /**
     * 拼出带签名的明文参数串，登录与读远程变量共用（对应模板两处相同写法）。
     */
    private fun signedParams(card: String, value: String): String {
        val t = (System.currentTimeMillis() / 1000).toString()
        val sign = Crypto.md5("kami=$card&markcode=$machineCode&t=$t&${LicenseConfig.APP_KEY}")
        return "kami=$card&markcode=$machineCode&t=$t&sign=$sign&value=$value"
    }

    /** 明文 -> hex(RC4(明文))，即请求里的 `data=` 字段。 */
    private fun encrypt(plain: String): String = Crypto.binToHex(
        Crypto.rc4(plain.toByteArray(Charsets.UTF_8), LicenseConfig.RC4_KEY.toByteArray())
    )

    /** 响应正文 -> RC4 解密后的 JSON；失败返回 null（含服务器返回纯文本错误的情况）。 */
    private fun parse(resp: String): JSONObject? {
        val body = resp.trim()
        if (body.isEmpty()) return null
        return try {
            val plain = Crypto.rc4(Crypto.hexToBin(body), LicenseConfig.RC4_KEY.toByteArray())
                .toString(Charsets.UTF_8).trim()
            JSONObject(plain)
        } catch (e: Exception) {
            null
        }
    }

    private fun post(query: String, postBody: String): String {
        val conn = URL("http://$host/$query").openConnection() as HttpURLConnection
        return try {
            conn.requestMethod = "POST"
            conn.connectTimeout = LicenseConfig.TIMEOUT_MS
            conn.readTimeout = LicenseConfig.TIMEOUT_MS
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.setRequestProperty("User-Agent", "Mozilla/4.0(compatible)")
            conn.outputStream.use { it.write(postBody.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            stream?.readBytes()?.toString(Charsets.UTF_8) ?: ""
        } catch (e: Exception) {
            ""
        } finally {
            conn.disconnect()
        }
    }
}
