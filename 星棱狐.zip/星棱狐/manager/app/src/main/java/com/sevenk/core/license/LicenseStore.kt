package com.sevenk.core.license

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings

/**
 * 激活状态持久化：本机 SharedPreferences 存已激活标记、到期时间/次数、卡密与机器码。
 */
object LicenseStore {
    private const val PREFS = "license_prefs"
    private const val KEY_ACTIVATED = "activated"
    private const val KEY_EXPIRE = "expire"
    private const val KEY_REMAIN = "remain"
    private const val KEY_IS_TIME = "is_time"
    private const val KEY_KAMI = "kami"
    private const val KEY_MACHINE = "machine"

    /** 当前是否处于已激活可用状态（未启用验证时恒为 true）。 */
    fun isActivated(ctx: Context): Boolean {
        if (!LicenseConfig.ENABLED) return true
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean(KEY_ACTIVATED, false)) return false
        if (p.getBoolean(KEY_IS_TIME, true)) {
            val exp = p.getLong(KEY_EXPIRE, 0)
            if (exp > 0 && exp < System.currentTimeMillis() / 1000) {
                return false // 已过期
            }
        }
        return true
    }

    /** 保存一次成功的激活。 */
    fun save(ctx: Context, expire: Long, remain: Long, isTime: Boolean, kami: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putLong(KEY_EXPIRE, expire)
            .putLong(KEY_REMAIN, remain)
            .putBoolean(KEY_IS_TIME, isTime)
            .putString(KEY_KAMI, kami)
            .apply()
    }

    /** 本机机器码：基于 ANDROID_ID 取 MD5，卸载重装一般不变（同一安装下稳定）。 */
    @SuppressLint("HardwareIds")
    fun machineCode(ctx: Context): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        p.getString(KEY_MACHINE, null)?.let { return it }
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "0000"
        val code = Crypto.md5("starfox-m$aid").substring(0, 32)
        p.edit().putString(KEY_MACHINE, code).apply()
        return code
    }
}
