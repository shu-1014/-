package com.sevenk.core.license

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LicenseUiState(
    val activated: Boolean,
    val checking: Boolean = false,
    val error: String? = null,
    val expireText: String? = null,
    /** 系统公告正文（`api/?id=notice` 取到才非空）。 */
    val notice: String? = null,
    /** 有新版本时的提示文案。 */
    val updateText: String? = null,
    /** 新版本下载地址，供「去下载」按钮使用。 */
    val updateUrl: String? = null,
    /** 后台要求强制更新且确有新版本，且允许拦截：此时不允许跳过激活。 */
    val forceUpdate: Boolean = false,
)

/**
 * 卡密验证 ViewModel。
 *
 * 对应 C++ 模板 `main.cpp` 的完整流程：
 *  1. 检查更新（`Weiyan::Update`）
 *  2. 获取公告（`Weiyan::Notice`）
 *  3. 卡密登录（`Weiyan::Login`）
 *  4. 读远程变量（`Weiyan::getValue`）
 *
 * 构造时读本机激活状态；未激活则后台线程拉取公告与更新信息，
 * [activate] 走后台线程调微验登录，成功后持久化并切到已激活。
 */
class LicenseViewModel(app: Application) : AndroidViewModel(app) {

    private val _ui = MutableStateFlow(LicenseUiState(activated = LicenseStore.isActivated(app)))
    val uiState: StateFlow<LicenseUiState> = _ui

    init {
        // 模板 main() 一上来就是 Update + Notice，这里保持同样顺序。
        // 网络失败不影响激活流程，只是不显示公告/更新条。
        loadNoticeAndUpdate()
    }

    private fun loadNoticeAndUpdate() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val (notice, update) = withContext(Dispatchers.IO) {
                val client = WeiyanClient(LicenseStore.machineCode(ctx))
                client.notice() to client.checkUpdate(LicenseConfig.APP_VERSION)
            }
            val cur = _ui.value
            _ui.value = cur.copy(
                notice = notice.text.takeIf { it.isNotBlank() },
                updateText = if (update.ok && update.hasNew) {
                    "发现新版本 ${update.latestVersion}" +
                        if (update.changeLog.isNotBlank()) "：${update.changeLog}" else ""
                } else null,
                updateUrl = if (update.ok && update.hasNew) update.downloadUrl.takeIf { it.isNotBlank() } else null,
                forceUpdate = LicenseConfig.FORCE_UPDATE_BLOCKS && update.ok && update.forceUpdate,
            )
        }
    }

    fun activate(kami: String) {
        if (kami.isBlank()) {
            _ui.value = _ui.value.copy(error = "请输入卡密")
            return
        }
        _ui.value = _ui.value.copy(checking = true, error = null)
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val result = withContext(Dispatchers.IO) {
                WeiyanClient(LicenseStore.machineCode(ctx)).login(kami.trim())
            }
            if (result.ok) {
                LicenseStore.save(ctx, result.expireTime, result.remain, result.isTimeCard, kami.trim())
                val text = if (result.isTimeCard) {
                    "激活成功，到期时间：${formatTime(result.expireTime)}"
                } else {
                    "激活成功，剩余次数：${result.remain}"
                }
                _ui.value = _ui.value.copy(checking = false, activated = true, error = null, expireText = text)
            } else {
                _ui.value = _ui.value.copy(checking = false, error = result.msg)
            }
        }
    }

    /** 点「去下载」：用系统浏览器打开后台配置的更新地址。 */
    fun openUpdateUrl() {
        val url = _ui.value.updateUrl ?: return
        val ctx = getApplication<Application>()
        val target = if (url.startsWith("http")) url else "http://$url"
        runCatching {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(target)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun formatTime(sec: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(sec * 1000))
}
